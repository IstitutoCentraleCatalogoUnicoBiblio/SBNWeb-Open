#!/bin/bash

export LANG="it_IT.UTF-8"
#ora="date +%Y-%m-%d-%H:%M:%S"
#echo "Inizio importa utenti "  `${ora}` > `${ora}`_importaUtenti.log

JAVA=$(which java)
$JAVA -Xmx1560m -classpath ./:postgresql-42.0.0.jre6.jar it.iccu.sbn.batch.servizi.ImportaUtentiLettori $1 $2 $3

#oraF="date +%Y-%m-%d-%H:%M:%S"
#echo "  " >>  `${ora}`_importaUtenti.log
#echo "Fine importa utenti "  `${oraF}` >>  `${ora}`_importaUtenti.log

